# A dataset for US Dancing with the Stars

Parsed from Wikipedia. https://en.wikipedia.org/w/index.php?title=Dancing_with_the_Stars_(American_season_1)

Note that this excludes multi-couple performances.

Also note that some performances have multiple songs associated with them, only the first song listed on wikipedia is recorded.

Similarly some performances have multiple dance-styles, but only the first dance-style listed on wikipedia is recorded.

Some professionals become judges, Some celebrities become judges.

One week the judges gave both a technical score and a performance score; those were averaged and just show as a single score.  All ranking scores (and multiple judge scores) were dropped.  This makes scores.csv a single judge giving a single score to a single performance.

performances.csv has a row per performance. This file include the celebrity and the professional that actually danced (including in the couple name and in the celebrity_id/professional_id column). That can be different from the celebrity/professional pairing for the season (sometimes a different professional dances with the celebrity (for all couples, or sometimes just a temporary substitution). 

The score for a dance with a substitution I think goes to the celebrity (for calculating weekly scores and overall winners).

couples.csv has just the name of the couple ... there is a chance that there are identically named couples across seasons.